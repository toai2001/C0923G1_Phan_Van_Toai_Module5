package org.example.rentapplicationbe;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RentApplicationBeApplication {

    public static void main(String[] args) {
        SpringApplication.run(RentApplicationBeApplication.class, args);
    }

}
