package org.example.rentapplicationbe.service;

import org.example.rentapplicationbe.model.User;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface IAccountService {
    Optional<User> findAccountByEmail(String email);


    Optional<User> findAccountByAccountName(String accountName);


    Optional<User> findAccountByPhone(String phoneNumber);

    String login(String nameAccount, String passWord) throws Exception;





}
