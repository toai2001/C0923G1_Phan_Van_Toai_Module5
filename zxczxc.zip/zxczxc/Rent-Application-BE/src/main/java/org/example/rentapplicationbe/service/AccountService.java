package org.example.rentapplicationbe.service;

import org.example.rentapplicationbe.config.JwtTokenUtil;
import org.example.rentapplicationbe.model.User;
import org.example.rentapplicationbe.repository.AccountRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;
import java.util.zip.DataFormatException;

@Service
public class AccountService implements IAccountService {
    @Autowired
    private AccountRepository accountRepository;
    @Autowired
    private JwtTokenUtil jwtTokenUtil;
    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public Optional<User> findAccountByEmail(String email) {
        return accountRepository.findByEmail(email);
    }

    @Override
    public Optional<User> findAccountByAccountName(String accountName) {
        return accountRepository.findByNameAccount(accountName);
    }

    @Override
    public Optional<User> findAccountByPhone(String phoneNumber) {
        return accountRepository.findByPhoneNumber(phoneNumber);
    }

    @Override
    public String login(String nameAccount, String passWord) throws Exception {
        Optional<User> optionalUser = accountRepository.findByNameAccount(nameAccount);
        if (optionalUser.isEmpty()) {
            throw new DataFormatException("Sai tai khoan hoac mat khau ");
        }
        User existingUser = optionalUser.get();

        // chua dang nhap google
        if (!passwordEncoder.matches(passWord, existingUser.getPassword())) {
            throw new BadCredentialsException("sai toan khoan hoac mat khau");
        }

        UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(
                nameAccount, passWord, existingUser.getAuthorities()
        );
        authenticationManager.authenticate(authenticationToken);
        return jwtTokenUtil.generateToken(optionalUser.get());
    }
}
