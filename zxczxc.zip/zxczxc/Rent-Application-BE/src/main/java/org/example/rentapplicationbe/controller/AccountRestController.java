package org.example.rentapplicationbe.controller;

import jakarta.servlet.http.HttpServletResponse;
import org.example.rentapplicationbe.model.User;
import org.example.rentapplicationbe.model.dto.AccountDTO;
import org.example.rentapplicationbe.model.dto.ApiResponse;
import org.example.rentapplicationbe.service.IAccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin("*")
@RequestMapping("/account")
public class AccountRestController {

    @Autowired
    private IAccountService iAccountService;
    @Autowired
    private PasswordEncoder passwordEncoder;

    @PostMapping("/login")
    public ResponseEntity<Object> loginAccount(HttpServletResponse response, @RequestBody
    AccountDTO accountDTO) { // đăng nhập
        ApiResponse<User> apiResponse = new ApiResponse<>(); // tạo apiResponse
        try {
            String token = iAccountService.login(accountDTO.getNameAccount(), accountDTO.getPassword()); // đăng nhập
            User user = iAccountService.findAccountByAccountName(accountDTO.getNameAccount()).get();// tìm user theo tên tài khoản

            apiResponse.setToken(token); // set token
            apiResponse.setDataRes(user); // set user
//            Cookie jwtCookie = new Cookie("JWT",token);
//            jwtCookie.setHttpOnly(true);
//            jwtCookie.setSecure(true);
//            jwtCookie.setPath("/");
//            jwtCookie.setMaxAge(7 * 24 * 60 * 60);
//            response.addCookie(jwtCookie);

            return ResponseEntity.ok(apiResponse); // trả về apiResponse

        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage()); // trả về lỗi
        }
    }
}
