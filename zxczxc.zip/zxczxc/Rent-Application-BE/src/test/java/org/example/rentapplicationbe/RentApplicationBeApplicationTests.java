package org.example.rentapplicationbe;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentApplicationBeApplicationTests {

    @Test
    void contextLoads() {
    }

}
